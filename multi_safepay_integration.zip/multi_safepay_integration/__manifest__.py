{
    'name': 'Multisafepay Integration',
    'depends': ['payment'],
    'data': [
        'data/payment_provider_msp.xml',
        'views/payment_provider.xml',
        'views/payment_template.xml',
    ],
}
