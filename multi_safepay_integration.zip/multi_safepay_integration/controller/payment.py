from odoo import http
from odoo.exceptions import ValidationError
from odoo.http import Controller, request, route


class MpsPayment(Controller):
    _return_url = '/payment/msp/return'
    _webhook_url = '/payment/msp/webhook'

    @route(route=['/shop/payment/msp'], auth="public", type="http", website=True,
           methods=['GET'])
    def msp_payment(self, **data):
        print(1234567)

        # Check the integrity of the notification
        tx_sudo = request.env['payment.transaction'].sudo()._get_tx_from_notification_data(
            'MSP', data
        )
        payment_data = tx_sudo.provider_id._msp_make_request(
                    f'/orders/{tx_sudo.reference}', method="GET"
                )
        print(payment_data['data']['status'])
        if payment_data['data']['status'] == 'completed':
            tx_sudo._set_done()
        print(tx_sudo)
        return request.redirect('/payment/status')
