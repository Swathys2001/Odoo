{
    'name': 'Systray increment',
    'depends': ['web'],
    'version': '16.0.1.0.0',
    "assets": {
        'web.assets_backend':
            [
                "owl/static/src/js/increment.js",
                "owl/static/src/xml/increment.xml",

        ]
    }
}