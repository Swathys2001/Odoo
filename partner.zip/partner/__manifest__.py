{
    'name': 'Session website',
    'version': '16.0.1.0.0',
    'depends': ['website'],
    'data': [
        'views/website_partner_menu.xml',
        'views/website_partner_template.xml',
    ],
    # 'assets': {
    #     'web.assets_frontend': [
    #
    #     ]

 # }


}