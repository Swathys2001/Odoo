{
    'name': 'Bool badge',
    'depends': ['web'],
    'version': '16.0.1.0.0',
    "assets": {
        'web.assets_backend':
            [
                "bool_badge/static/src/js/bool_badge.js",
                "bool_badge/static/src/xml/bool_badge.xml",
        ]
    }
}
